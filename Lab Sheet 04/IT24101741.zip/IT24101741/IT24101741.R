setwd("C:/Users/it24101741/Desktop/IT24101741")
getwd()
branch_data<-read.csv("Exercise.txt",header=TRUE)
head(branch_data)
str(branch_data)

boxplot(branch_data$Sales_X1, main = "Boxplot of sales",ylab = "Sales",col = "lightblue",border="darkblue")
summary(branch_data$Advertising_X2)
iqr_value<-IQR(branch_data$Advertising_X2)
iqr_value

find_outliers<-function(x){
  Q1<-quantile(x,0.25,na.rm = TRUE)
  Q3<-quantile(x,0.75,na.rm = TRUE)
  IQR_value<-IQR(x,na.rm = TRUE)
  lower_bound<-Q1-1.5*IQR_value
  upper_bound<-Q3 + 1.5*IQR_value
  outliers<-x[x<lower_bound|x>upper_bound]
  return(outliers)
}

outliers_in_years<-
  find_outliers(branch_data$Years_X3)
outliers_in_years
