setwd("C:/Users/Arulkumaran/Desktop/IT24101741")
getwd()
Delivery_Times <- read.table("Exercise - Lab 05.txt", header = TRUE)
head(Delivery_Times)


names(Delivery_Times) <- "Time"
Delivery_Times$Time <- as.numeric(Delivery_Times$Time)
hist(
  Delivery_Times$Time,
  breaks = seq(20, 70, by = 50/9),   
  right = FALSE,
  main = "Histogram of Delivery Times",
  xlab = "Delivery Time (minutes)",
  col = "skyblue",
  border = "black"
)


breaks <- seq(20, 70, by = 50/9)
freq_table <- hist(
  Delivery_Times$Time,
  breaks = breaks,
  right = FALSE,
  plot = FALSE
)
cum_freq <- cumsum(freq_table$counts)
class_bounds <- freq_table$breaks[-1]   

plot(
  class_bounds,
  cum_freq,
  type = "o",
  col = "red",
  main = "Cumulative Frequency Polygon (Ogive)",
  xlab = "Delivery Time",
  ylab = "Cumulative Frequency"
)




